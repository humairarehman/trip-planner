import 'dart:convert';
import 'package:http/http.dart' as http;
import '../model/weather_model.dart';
import '../utils/app_theme.dart';

class WeatherService {
  static const String _baseUrl = AppConstants.weatherBaseUrl;
  static const String _apiKey = AppConstants.weatherApiKey;

  Future<WeatherModel> getCurrentWeather(String city) async {
    final url = Uri.parse(
      '$_baseUrl/weather?q=${Uri.encodeComponent(city)}&appid=$_apiKey&units=metric',
    );

    final response = await http.get(url);

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      return WeatherModel.fromMap(data);
    } else if (response.statusCode == 404) {
      throw Exception('City not found');
    } else {
      throw Exception('Failed to fetch weather: ${response.statusCode}');
    }
  }

  Future<List<ForecastDay>> getForecast(String city) async {
    final url = Uri.parse(
      '$_baseUrl/forecast?q=${Uri.encodeComponent(city)}&appid=$_apiKey&units=metric&cnt=40',
    );

    final response = await http.get(url);

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      final list = data['list'] as List<dynamic>;

      // Group by day and take one entry per day (noon)
      final Map<String, ForecastDay> dayMap = {};
      for (final item in list) {
        final date =
        DateTime.fromMillisecondsSinceEpoch((item['dt'] as int) * 1000);
        final key =
            '${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';
        if (!dayMap.containsKey(key) || date.hour == 12) {
          dayMap[key] = ForecastDay.fromMap(item);
        }
      }

      return dayMap.values.take(7).toList();
    } else {
      throw Exception('Failed to fetch forecast');
    }
  }
}