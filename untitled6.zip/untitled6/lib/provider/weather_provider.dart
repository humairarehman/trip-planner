import 'package:flutter/material.dart';
import '../services/weather_service.dart';
import '../model/weather_model.dart';

class WeatherProvider extends ChangeNotifier {
  final WeatherService _weatherService = WeatherService();

  WeatherModel? _currentWeather;
  List<ForecastDay> _forecast = [];
  bool _isLoading = false;
  String? _errorMessage;
  String? _lastCity;

  WeatherModel? get currentWeather => _currentWeather;
  List<ForecastDay> get forecast => _forecast;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;
  String? get lastCity => _lastCity;

  Future<void> fetchWeather(String city) async {
    if (city.trim().isEmpty) return;

    try {
      _isLoading = true;
      _errorMessage = null;
      _lastCity = city;
      notifyListeners();

      _currentWeather = await _weatherService.getCurrentWeather(city);
      _forecast = await _weatherService.getForecast(city);

      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _errorMessage = 'Could not fetch weather for "$city". Check the city name.';
      _isLoading = false;
      notifyListeners();
    }
  }

  void clearWeather() {
    _currentWeather = null;
    _forecast = [];
    _errorMessage = null;
    _lastCity = null;
    notifyListeners();
  }
}