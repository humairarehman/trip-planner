import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:uuid/uuid.dart';
import '../model/trip_model.dart';

class TripProvider extends ChangeNotifier {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final _uuid = const Uuid();

  List<TripModel> _trips = [];
  bool _isLoading = false;
  String? _errorMessage;

  List<TripModel> get trips => _trips;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;

  List<TripModel> get upcomingTrips =>
      _trips.where((t) => t.isUpcoming).toList()
        ..sort((a, b) => a.startDate.compareTo(b.startDate));

  List<TripModel> get ongoingTrips => _trips.where((t) => t.isOngoing).toList();

  List<TripModel> get pastTrips =>
      _trips.where((t) => t.isPast).toList()
        ..sort((a, b) => b.endDate.compareTo(a.endDate));

  Stream<List<TripModel>> getUserTripsStream(String userId) {
    return _firestore
        .collection('trips')
        .where('memberIds', arrayContains: userId)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snapshot) {
      _trips = snapshot.docs
          .map((doc) => TripModel.fromMap(doc.data(), doc.id))
          .toList();
      notifyListeners();
      return _trips;
    });
  }

  Future<TripModel?> createTrip({
    required String title,
    required String destination,
    required DateTime startDate,
    required DateTime endDate,
    required String notes,
    required String creatorId,
  }) async {
    try {
      _isLoading = true;
      notifyListeners();

      // Build itinerary days
      final days = <ItineraryDay>[];
      final duration = endDate.difference(startDate).inDays + 1;
      for (int i = 0; i < duration; i++) {
        days.add(ItineraryDay(
          dayNumber: i + 1,
          date: startDate.add(Duration(days: i)),
          items: [],
        ));
      }

      final trip = TripModel(
        id: '',
        title: title,
        destination: destination,
        startDate: startDate,
        endDate: endDate,
        notes: notes,
        creatorId: creatorId,
        memberIds: [creatorId],
        itinerary: days,
        createdAt: DateTime.now(),
      );

      final docRef =
      await _firestore.collection('trips').add(trip.toMap());

      final createdTrip = TripModel(
        id: docRef.id,
        title: trip.title,
        destination: trip.destination,
        startDate: trip.startDate,
        endDate: trip.endDate,
        notes: trip.notes,
        creatorId: trip.creatorId,
        memberIds: trip.memberIds,
        itinerary: trip.itinerary,
        createdAt: trip.createdAt,
      );

      _isLoading = false;
      notifyListeners();
      return createdTrip;
    } catch (e) {
      _errorMessage = 'Failed to create trip: $e';
      _isLoading = false;
      notifyListeners();
      return null;
    }
  }

  Future<bool> updateTrip(TripModel trip) async {
    try {
      await _firestore
          .collection('trips')
          .doc(trip.id)
          .update(trip.toMap());
      return true;
    } catch (e) {
      _errorMessage = 'Failed to update trip: $e';
      notifyListeners();
      return false;
    }
  }

  Future<bool> deleteTrip(String tripId) async {
    try {
      await _firestore.collection('trips').doc(tripId).delete();
      // Also delete all messages for this trip
      final messages = await _firestore
          .collection('messages')
          .where('tripId', isEqualTo: tripId)
          .get();
      for (final doc in messages.docs) {
        await doc.reference.delete();
      }
      return true;
    } catch (e) {
      _errorMessage = 'Failed to delete trip: $e';
      notifyListeners();
      return false;
    }
  }

  Future<bool> addItineraryItem({
    required TripModel trip,
    required int dayIndex,
    required String title,
    required String type,
    String? description,
    String? time,
  }) async {
    try {
      final item = ItineraryItem(
        id: _uuid.v4(),
        title: title,
        description: description,
        type: type,
        time: time,
      );

      final updatedDays = List<ItineraryDay>.from(trip.itinerary);
      final day = updatedDays[dayIndex];
      final updatedItems = List<ItineraryItem>.from(day.items)..add(item);
      updatedDays[dayIndex] = ItineraryDay(
        dayNumber: day.dayNumber,
        date: day.date,
        items: updatedItems,
      );

      final updatedTrip = trip.copyWith(itinerary: updatedDays);
      await _firestore
          .collection('trips')
          .doc(trip.id)
          .update({'itinerary': updatedDays.map((d) => d.toMap()).toList()});

      return true;
    } catch (e) {
      _errorMessage = 'Failed to add item: $e';
      notifyListeners();
      return false;
    }
  }

  Future<bool> removeItineraryItem({
    required TripModel trip,
    required int dayIndex,
    required String itemId,
  }) async {
    try {
      final updatedDays = List<ItineraryDay>.from(trip.itinerary);
      final day = updatedDays[dayIndex];
      final updatedItems =
      day.items.where((item) => item.id != itemId).toList();
      updatedDays[dayIndex] = ItineraryDay(
        dayNumber: day.dayNumber,
        date: day.date,
        items: updatedItems,
      );

      await _firestore
          .collection('trips')
          .doc(trip.id)
          .update({'itinerary': updatedDays.map((d) => d.toMap()).toList()});

      return true;
    } catch (e) {
      _errorMessage = 'Failed to remove item: $e';
      notifyListeners();
      return false;
    }
  }

  Future<bool> addMember(String tripId, String userId) async {
    try {
      await _firestore.collection('trips').doc(tripId).update({
        'memberIds': FieldValue.arrayUnion([userId]),
      });
      return true;
    } catch (e) {
      return false;
    }
  }

  Future<TripModel?> getTripById(String tripId) async {
    try {
      final doc =
      await _firestore.collection('trips').doc(tripId).get();
      if (doc.exists) {
        return TripModel.fromMap(doc.data()!, doc.id);
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  Stream<TripModel?> getTripStream(String tripId) {
    return _firestore
        .collection('trips')
        .doc(tripId)
        .snapshots()
        .map((doc) => doc.exists ? TripModel.fromMap(doc.data()!, doc.id) : null);
  }
}