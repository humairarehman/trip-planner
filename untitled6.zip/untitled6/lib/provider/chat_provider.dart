import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../model/chat_messages.dart';

class ChatProvider extends ChangeNotifier {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  bool _isSending = false;
  String? _errorMessage;

  bool get isSending => _isSending;
  String? get errorMessage => _errorMessage;

  Stream<List<ChatMessage>> getMessagesStream(String tripId) {
    return _firestore
        .collection('messages')
        .where('tripId', isEqualTo: tripId)
        .orderBy('timestamp', descending: false)
        .snapshots()
        .map((snapshot) => snapshot.docs
        .map((doc) => ChatMessage.fromMap(doc.data(), doc.id))
        .toList());
  }

  Future<bool> sendMessage({
    required String tripId,
    required String senderId,
    required String senderName,
    String? senderPhotoUrl,
    required String text,
  }) async {
    if (text.trim().isEmpty) return false;

    try {
      _isSending = true;
      notifyListeners();

      final message = ChatMessage(
        id: '',
        tripId: tripId,
        senderId: senderId,
        senderName: senderName,
        senderPhotoUrl: senderPhotoUrl,
        text: text.trim(),
        timestamp: DateTime.now(),
      );

      await _firestore.collection('messages').add(message.toMap());

      _isSending = false;
      notifyListeners();
      return true;
    } catch (e) {
      _errorMessage = 'Failed to send message: $e';
      _isSending = false;
      notifyListeners();
      return false;
    }
  }

  Future<bool> deleteMessage(String messageId) async {
    try {
      await _firestore.collection('messages').doc(messageId).delete();
      return true;
    } catch (e) {
      return false;
    }
  }
}