// lib/app_color.dart
import 'package:flutter/material.dart';

class AppColors {
  // ── Primary ───────────────────────────────────────────────
  static const Color primary       = Color(0xFF1D9E75);
  static const Color primaryDark   = Color(0xFF0F6E56);
  static const Color primaryLight  = Color(0xFFE1F5EE);
  static const Color primaryMid    = Color(0xFF5DCAA5);

  // ── Accent ────────────────────────────────────────────────
  static const Color accent        = Color(0xFF5DCAA5);
  static const Color amber         = Color(0xFFEF9F27);
  static const Color amberLight    = Color(0xFFFAEEDA);
  static const Color coral         = Color(0xFFD85A30);
  static const Color coralLight    = Color(0xFFFAECE7);
  static const Color blue          = Color(0xFF378ADD);
  static const Color blueLight     = Color(0xFFE6F1FB);
  static const Color red           = Color(0xFFE24B4A);
  static const Color redLight      = Color(0xFFFCEBEB);

  // ── Background ────────────────────────────────────────────
  static const Color bg            = Color(0xFFF7F6F2);
  static const Color background    = Color(0xFFF7F6F2);
  static const Color surface       = Color(0xFFFFFFFF);
  static const Color cardBg        = Color(0xFFFFFFFF);

  // ── Gradient ──────────────────────────────────────────────
  static const Color gradientStart = Color(0xFF1D9E75);
  static const Color gradientEnd   = Color(0xFF0F6E56);

  // ── Border ────────────────────────────────────────────────
  static const Color border        = Color(0x17000000);
  static const Color borderMd      = Color(0x24000000);

  // ── Text ──────────────────────────────────────────────────
  static const Color text          = Color(0xFF1a1a18);
  static const Color text2         = Color(0xFF5a5a56);
  static const Color text3         = Color(0xFF999994);
  static const Color textWhite     = Color(0xFFFFFFFF);
  static const Color textPrimary   = Color(0xFF1a1a18);
  static const Color textSecondary = Color(0xFF5a5a56);
  static const Color textHint      = Color(0xFF999994);

  // ── Status ────────────────────────────────────────────────
  static const Color success       = Color(0xFF1D9E75);
  static const Color warning       = Color(0xFFEF9F27);
  static const Color error         = Color(0xFFE24B4A);
  static const Color info          = Color(0xFF378ADD);

  // ── Shadow ────────────────────────────────────────────────
  static List<BoxShadow> get cardShadow => [
    BoxShadow(
      color: Colors.black.withValues(alpha: 0.06),
      blurRadius: 12,
      offset: const Offset(0, 4),
    ),
  ];

  static List<BoxShadow> get shadowLg => [
    BoxShadow(
      color: Colors.black.withValues(alpha: 0.10),
      blurRadius: 32,
      offset: const Offset(0, 8),
    ),
  ];
}