import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import '../provider/auth_provider.dart';      // ← one level up
import '../provider/trip_provider.dart';      // ← one level up
import '../model/trip_model.dart';            // ← one level up
import '../utils/app_theme.dart';             // ← one level up
import '../widget/comon_widget.dart';         // ← one level up
import 'create_trip_screen.dart';
import 'trip_detail_screen.dart';

class TripsScreen extends StatelessWidget {
  const TripsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthProvider>().currentUser;
    if (user == null) return const SizedBox();

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: StreamBuilder<List<TripModel>>(
          stream: context.read<TripProvider>().getUserTripsStream(user.uid),
          builder: (context, snapshot) {
            return CustomScrollView(
              slivers: [
                // Header
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
                    child: Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Hello, ${user.name.split(' ').first} 👋',
                                  style: GoogleFonts.poppins(
                                      fontSize: 14,
                                      color: AppColors.textSecondary)),
                              Text('My Trips',
                                  style: GoogleFonts.poppins(
                                      fontSize: 26,
                                      fontWeight: FontWeight.w700,
                                      color: AppColors.textPrimary)),
                            ],
                          ),
                        ),
                        GestureDetector(
                          onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) => const CreateTripScreen()),
                          ),
                          child: Container(
                            width: 44,
                            height: 44,
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(
                                colors: [
                                  AppColors.gradientStart,
                                  AppColors.gradientEnd
                                ],
                              ),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: const Icon(Icons.add,
                                color: Colors.white, size: 24),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                if (snapshot.connectionState == ConnectionState.waiting)
                  const SliverFillRemaining(
                    child: Center(child: CircularProgressIndicator()),
                  )
                else if (!snapshot.hasData || snapshot.data!.isEmpty)
                  SliverFillRemaining(
                    child: EmptyState(
                      icon: Icons.luggage_outlined,
                      title: 'No trips yet',
                      subtitle:
                      'Create your first trip and start planning your adventure!',
                      actionLabel: '+ Create Trip',
                      onAction: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => const CreateTripScreen()),
                      ),
                    ),
                  )
                else
                  _TripSections(trips: snapshot.data!),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _TripSections extends StatelessWidget {
  final List<TripModel> trips;
  const _TripSections({required this.trips});

  @override
  Widget build(BuildContext context) {
    final ongoing = trips.where((t) => t.isOngoing).toList();
    final upcoming = trips.where((t) => t.isUpcoming).toList()
      ..sort((a, b) => a.startDate.compareTo(b.startDate));
    final past = trips.where((t) => t.isPast).toList()
      ..sort((a, b) => b.endDate.compareTo(a.endDate));

    return SliverList(
      delegate: SliverChildListDelegate([
        const SizedBox(height: 24),
        if (ongoing.isNotEmpty) ...[
          _SectionTitle(title: '✈️ Ongoing', count: ongoing.length),
          ...ongoing.map((t) => _TripCard(trip: t, isOngoing: true)),
        ],
        if (upcoming.isNotEmpty) ...[
          _SectionTitle(title: '🗓️ Upcoming', count: upcoming.length),
          ...upcoming.map((t) => _TripCard(trip: t)),
        ],
        if (past.isNotEmpty) ...[
          _SectionTitle(title: '📸 Past Trips', count: past.length),
          ...past.map((t) => _TripCard(trip: t, isPast: true)),
        ],
        const SizedBox(height: 100),
      ]),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;
  final int count;
  const _SectionTitle({required this.title, required this.count});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 8),
      child: Row(
        children: [
          Text(title,
              style: GoogleFonts.poppins(
                  fontSize: 16, fontWeight: FontWeight.w600)),
          const SizedBox(width: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
            decoration: BoxDecoration(
              color: AppColors.primary.withOpacity(0.1),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text('$count',
                style: GoogleFonts.poppins(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: AppColors.primary)),
          ),
        ],
      ),
    );
  }
}

class _TripCard extends StatelessWidget {
  final TripModel trip;
  final bool isOngoing;
  final bool isPast;

  const _TripCard({
    required this.trip,
    this.isOngoing = false,
    this.isPast = false,
  });

  @override
  Widget build(BuildContext context) {
    final dateFormat = DateFormat('MMM d');
    final color = isOngoing
        ? AppColors.success
        : isPast
        ? AppColors.textSecondary
        : AppColors.primary;

    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
      child: GestureDetector(
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => TripDetailScreen(trip: trip)),
        ),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppColors.border),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.04),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Column(
            children: [
              // Top color bar
              Container(
                height: 4,
                decoration: BoxDecoration(
                  color: color,
                  borderRadius: const BorderRadius.vertical(
                      top: Radius.circular(16)),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(trip.title,
                              style: GoogleFonts.poppins(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600,
                                  color: AppColors.textPrimary)),
                        ),
                        StatusBadge(
                          label: isOngoing
                              ? 'Ongoing'
                              : isPast
                              ? 'Completed'
                              : 'Upcoming',
                          color: color,
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        const Icon(Icons.location_on_outlined,
                            size: 15, color: AppColors.textSecondary),
                        const SizedBox(width: 4),
                        Text(trip.destination,
                            style: GoogleFonts.poppins(
                                fontSize: 13,
                                color: AppColors.textSecondary)),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        _InfoChip(
                          icon: Icons.calendar_today_outlined,
                          label:
                          '${dateFormat.format(trip.startDate)} – ${dateFormat.format(trip.endDate)}',
                        ),
                        const SizedBox(width: 10),
                        _InfoChip(
                          icon: Icons.schedule_outlined,
                          label: '${trip.durationDays} days',
                        ),
                        const SizedBox(width: 10),
                        _InfoChip(
                          icon: Icons.people_outline,
                          label: '${trip.memberIds.length}',
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _InfoChip extends StatelessWidget {
  final IconData icon;
  final String label;
  const _InfoChip({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 13, color: AppColors.textSecondary),
        const SizedBox(width: 4),
        Text(label,
            style: GoogleFonts.poppins(
                fontSize: 12, color: AppColors.textSecondary)),
      ],
    );
  }
}