import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import '../../provider/weather_provider.dart';
import '../../model/weather_model.dart';
import '../../utils/app_theme.dart';
import '../../widget/comon_widget.dart';

class WeatherTab extends StatelessWidget {
  final String city;
  const WeatherTab({super.key, required this.city});

  @override
  Widget build(BuildContext context) {
    final weatherProvider = context.watch<WeatherProvider>();

    if (weatherProvider.isLoading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (weatherProvider.errorMessage != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.cloud_off_outlined,
                  size: 60, color: AppColors.textSecondary),
              const SizedBox(height: 16),
              Text(weatherProvider.errorMessage!,
                  style: GoogleFonts.poppins(
                      color: AppColors.textSecondary, fontSize: 14),
                  textAlign: TextAlign.center),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: () =>
                    context.read<WeatherProvider>().fetchWeather(city),
                child: const Text('Retry'),
              ),
            ],
          ),
        ),
      );
    }

    final weather = weatherProvider.currentWeather;
    final forecast = weatherProvider.forecast;

    if (weather == null) {
      return const EmptyState(
        icon: Icons.wb_sunny_outlined,
        title: 'No weather data',
        subtitle: 'Could not fetch weather information.',
      );
    }

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          // Main weather card
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF4FC3F7), Color(0xFF0288D1)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(weather.city,
                            style: GoogleFonts.poppins(
                                fontSize: 20,
                                fontWeight: FontWeight.w700,
                                color: Colors.white)),
                        Text(
                          'Today, ${DateFormat('MMM d').format(DateTime.now())}',
                          style: GoogleFonts.poppins(
                              fontSize: 13, color: Colors.white70),
                        ),
                      ],
                    ),
                    Image.network(weather.iconUrl, width: 64, height: 64,
                        errorBuilder: (_, __, ___) =>
                        const Icon(Icons.wb_sunny,
                            size: 64, color: Colors.white)),
                  ],
                ),
                const SizedBox(height: 16),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('${weather.temperature.round()}',
                        style: GoogleFonts.poppins(
                            fontSize: 64,
                            fontWeight: FontWeight.w200,
                            color: Colors.white)),
                    Padding(
                      padding: const EdgeInsets.only(top: 12),
                      child: Text('°C',
                          style: GoogleFonts.poppins(
                              fontSize: 24,
                              color: Colors.white70)),
                    ),
                    const Spacer(),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          weather.description
                              .split(' ')
                              .map((w) => w[0].toUpperCase() + w.substring(1))
                              .join(' '),
                          style: GoogleFonts.poppins(
                              fontSize: 14, color: Colors.white),
                        ),
                        Text('Feels ${weather.feelsLike.round()}°C',
                            style: GoogleFonts.poppins(
                                fontSize: 12, color: Colors.white70)),
                        Text(
                            'H:${weather.tempMax.round()}° L:${weather.tempMin.round()}°',
                            style: GoogleFonts.poppins(
                                fontSize: 12, color: Colors.white70)),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _WeatherStat(
                      icon: Icons.water_drop_outlined,
                      label: 'Humidity',
                      value: '${weather.humidity}%',
                    ),
                    _WeatherStat(
                      icon: Icons.air,
                      label: 'Wind',
                      value: '${weather.windSpeed.round()} m/s',
                    ),
                  ],
                ),
              ],
            ),
          ),

          const SizedBox(height: 20),

          // 7-Day Forecast
          if (forecast.isNotEmpty) ...[
            Align(
              alignment: Alignment.centerLeft,
              child: Text('7-Day Forecast',
                  style: GoogleFonts.poppins(
                      fontSize: 15, fontWeight: FontWeight.w600)),
            ),
            const SizedBox(height: 12),
            ...forecast.map((day) => _ForecastRow(day: day)),
          ],

          const SizedBox(height: 80),
        ],
      ),
    );
  }
}

class _WeatherStat extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  const _WeatherStat(
      {required this.icon, required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Icon(icon, size: 20, color: Colors.white70),
        const SizedBox(height: 4),
        Text(value,
            style: GoogleFonts.poppins(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: Colors.white)),
        Text(label,
            style: GoogleFonts.poppins(
                fontSize: 11, color: Colors.white70)),
      ],
    );
  }
}

class _ForecastRow extends StatelessWidget {
  final ForecastDay day;
  const _ForecastRow({required this.day});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          Expanded(
            flex: 2,
            child: Text(DateFormat('EEE, MMM d').format(day.date),
                style: GoogleFonts.poppins(
                    fontSize: 13, fontWeight: FontWeight.w500)),
          ),
          Image.network(day.iconUrl, width: 32, height: 32,
              errorBuilder: (_, __, ___) =>
              const Icon(Icons.wb_sunny, size: 32)),
          const SizedBox(width: 12),
          Expanded(
            flex: 2,
            child: Text(
              day.description
                  .split(' ')
                  .map((w) => w[0].toUpperCase() + w.substring(1))
                  .join(' '),
              style: GoogleFonts.poppins(
                  fontSize: 12, color: AppColors.textSecondary),
              overflow: TextOverflow.ellipsis,
            ),
          ),
          Text(
            '${day.tempMax.round()}° / ${day.tempMin.round()}°',
            style: GoogleFonts.poppins(
                fontSize: 13, fontWeight: FontWeight.w600),
          ),
        ],
      ),
    );
  }
}