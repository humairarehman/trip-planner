import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../provider/weather_provider.dart';
import '../../utils/app_theme.dart';
import '../../widget/comon_widget.dart';
import 'weather_tab.dart';

class ExploreScreen extends StatefulWidget {
  const ExploreScreen({super.key});

  @override
  State<ExploreScreen> createState() => _ExploreScreenState();
}

class _ExploreScreenState extends State<ExploreScreen> {
  final _searchController = TextEditingController();
  String? _searchedCity;

  static const List<_PopularCity> _popularCities = [
    _PopularCity('Paris', '🇫🇷', 'Romance & Art'),
    _PopularCity('Tokyo', '🇯🇵', 'Culture & Tech'),
    _PopularCity('New York', '🇺🇸', 'Urban Energy'),
    _PopularCity('Dubai', '🇦🇪', 'Luxury & Modern'),
    _PopularCity('Bali', '🇮🇩', 'Nature & Temples'),
    _PopularCity('Istanbul', '🇹🇷', 'East meets West'),
    _PopularCity('London', '🇬🇧', 'History & Culture'),
    _PopularCity('Bangkok', '🇹🇭', 'Food & Temples'),
    _PopularCity('Barcelona', '🇪🇸', 'Art & Beach'),
  ];

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _searchCity(String city) {
    if (city.trim().isEmpty) return;
    setState(() => _searchedCity = city.trim());
    context.read<WeatherProvider>().fetchWeather(city.trim());
    FocusScope.of(context).unfocus();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Explore',
                      style: GoogleFonts.poppins(
                          fontSize: 26,
                          fontWeight: FontWeight.w700,
                          color: AppColors.textPrimary)),
                  Text('Search cities & check weather',
                      style: GoogleFonts.poppins(
                          fontSize: 13, color: AppColors.textSecondary)),
                  const SizedBox(height: 16),
                  // Search bar
                  Row(
                    children: [
                      Expanded(
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(color: AppColors.border),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.04),
                                blurRadius: 8,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: TextField(
                            controller: _searchController,
                            style: GoogleFonts.poppins(fontSize: 14),
                            decoration: InputDecoration(
                              hintText: 'Search a city...',
                              hintStyle: GoogleFonts.poppins(
                                  color: AppColors.textSecondary),
                              prefixIcon: const Icon(Icons.search,
                                  color: AppColors.textSecondary),
                              border: InputBorder.none,
                              contentPadding: const EdgeInsets.symmetric(
                                  vertical: 14),
                            ),
                            textInputAction: TextInputAction.search,
                            onSubmitted: _searchCity,
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      GestureDetector(
                        onTap: () => _searchCity(_searchController.text),
                        child: Container(
                          width: 50,
                          height: 50,
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [
                                AppColors.gradientStart,
                                AppColors.gradientEnd
                              ],
                            ),
                            borderRadius: BorderRadius.circular(14),
                          ),
                          child: const Icon(Icons.search,
                              color: Colors.white),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: 16),

            // Content
            Expanded(
              child: _searchedCity != null
                  ? _WeatherResultView(city: _searchedCity!)
                  : _PopularCitiesView(
                cities: _popularCities,
                onCityTap: (city) {
                  _searchController.text = city;
                  _searchCity(city);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _WeatherResultView extends StatelessWidget {
  final String city;
  const _WeatherResultView({required this.city});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 8),
          child: Row(
            children: [
              Text('Weather in $city',
                  style: GoogleFonts.poppins(
                      fontSize: 15, fontWeight: FontWeight.w600)),
              const Spacer(),
              TextButton.icon(
                onPressed: () {
                  context.read<WeatherProvider>().clearWeather();
                },
                icon: const Icon(Icons.arrow_back, size: 14),
                label: const Text('Back'),
                style: TextButton.styleFrom(
                    foregroundColor: AppColors.textSecondary),
              ),
            ],
          ),
        ),
        Expanded(child: WeatherTab(city: city)),
      ],
    );
  }
}

class _PopularCitiesView extends StatelessWidget {
  final List<_PopularCity> cities;
  final Function(String) onCityTap;
  const _PopularCitiesView(
      {required this.cities, required this.onCityTap});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Popular Destinations',
              style: GoogleFonts.poppins(
                  fontSize: 15, fontWeight: FontWeight.w600)),
          const SizedBox(height: 12),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
              childAspectRatio: 1,
            ),
            itemCount: cities.length,
            itemBuilder: (context, index) {
              final city = cities[index];
              return GestureDetector(
                onTap: () => onCityTap(city.name),
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: AppColors.border),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.04),
                        blurRadius: 6,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(city.flag,
                          style: const TextStyle(fontSize: 28)),
                      const SizedBox(height: 6),
                      Text(city.name,
                          style: GoogleFonts.poppins(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: AppColors.textPrimary)),
                      Text(city.tagline,
                          style: GoogleFonts.poppins(
                              fontSize: 9,
                              color: AppColors.textSecondary),
                          textAlign: TextAlign.center),
                    ],
                  ),
                ),
              );
            },
          ),
          const SizedBox(height: 24),
          // Travel tips
          Text('Travel Tips',
              style: GoogleFonts.poppins(
                  fontSize: 15, fontWeight: FontWeight.w600)),
          const SizedBox(height: 12),
          ..._tips.map((tip) => _TipCard(tip: tip)),
        ],
      ),
    );
  }

  static const List<_Tip> _tips = [
    _Tip(
      icon: Icons.umbrella_outlined,
      title: 'Check Weather Before You Go',
      subtitle: 'Always check the forecast for your destination a week ahead.',
      color: Color(0xFF4FC3F7),
    ),
    _Tip(
      icon: Icons.group_outlined,
      title: 'Plan With Your Group',
      subtitle: 'Use the group chat to coordinate and agree on activities.',
      color: Color(0xFF81C784),
    ),
    _Tip(
      icon: Icons.calendar_today_outlined,
      title: 'Build Your Itinerary Early',
      subtitle: 'Plan day-by-day activities so nothing is left to chance.',
      color: AppColors.accent,
    ),
  ];
}

class _TipCard extends StatelessWidget {
  final _Tip tip;
  const _TipCard({required this.tip});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: tip.color.withOpacity(0.15),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(tip.icon, size: 20, color: tip.color),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(tip.title,
                    style: GoogleFonts.poppins(
                        fontSize: 13, fontWeight: FontWeight.w600)),
                Text(tip.subtitle,
                    style: GoogleFonts.poppins(
                        fontSize: 11, color: AppColors.textSecondary)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _PopularCity {
  final String name;
  final String flag;
  final String tagline;
  const _PopularCity(this.name, this.flag, this.tagline);
}

class _Tip {
  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;
  const _Tip(
      {required this.icon,
        required this.title,
        required this.subtitle,
        required this.color});
}