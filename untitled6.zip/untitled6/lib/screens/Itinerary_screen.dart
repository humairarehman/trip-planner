import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';
import '../../model/trip_model.dart';
import '../../provider/trip_provider.dart';
import '../../utils/app_theme.dart';
import '../../widget/comon_widget.dart';

class ItineraryScreen extends StatefulWidget {
  final TripModel trip;
  const ItineraryScreen({super.key, required this.trip});

  @override
  State<ItineraryScreen> createState() => _ItineraryScreenState();
}

class _ItineraryScreenState extends State<ItineraryScreen> {
  int _selectedDayIndex = 0;

  @override
  Widget build(BuildContext context) {
    final trip = widget.trip;
    if (trip.itinerary.isEmpty) {
      return const EmptyState(
        icon: Icons.calendar_view_day_outlined,
        title: 'No itinerary days',
        subtitle: 'The trip duration may be 0 days.',
      );
    }

    final selectedDay = trip.itinerary[_selectedDayIndex];
    final dateFormat = DateFormat('EEE, MMM d');

    return Column(
      children: [
        // Day tabs
        SizedBox(
          height: 72,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            itemCount: trip.itinerary.length,
            itemBuilder: (context, index) {
              final day = trip.itinerary[index];
              final isSelected = index == _selectedDayIndex;
              return GestureDetector(
                onTap: () => setState(() => _selectedDayIndex = index),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  margin: const EdgeInsets.only(right: 8),
                  padding: const EdgeInsets.symmetric(
                      horizontal: 16, vertical: 6),
                  decoration: BoxDecoration(
                    color: isSelected ? AppColors.primary : Colors.white,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: isSelected
                          ? AppColors.primary
                          : AppColors.border,
                    ),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text('Day ${day.dayNumber}',
                          style: GoogleFonts.poppins(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: isSelected
                                  ? Colors.white
                                  : AppColors.textSecondary)),
                      Text(
                        DateFormat('MMM d').format(day.date),
                        style: GoogleFonts.poppins(
                          fontSize: 11,
                          color: isSelected
                              ? Colors.white70
                              : AppColors.textSecondary,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),

        // Day header
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
          child: Row(
            children: [
              Text(
                'Day ${selectedDay.dayNumber} — ${dateFormat.format(selectedDay.date)}',
                style: GoogleFonts.poppins(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: AppColors.textPrimary),
              ),
              const Spacer(),
              Text('${selectedDay.items.length} items',
                  style: GoogleFonts.poppins(
                      fontSize: 12, color: AppColors.textSecondary)),
            ],
          ),
        ),

        // Items list
        Expanded(
          child: selectedDay.items.isEmpty
              ? EmptyState(
            icon: Icons.add_circle_outline,
            title: 'No plans yet',
            subtitle: 'Add places or activities for this day',
            actionLabel: '+ Add Activity',
            onAction: () => _showAddDialog(context, _selectedDayIndex),
          )
              : ListView.builder(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: selectedDay.items.length + 1,
            itemBuilder: (context, index) {
              if (index == selectedDay.items.length) {
                return Padding(
                  padding: const EdgeInsets.only(top: 8, bottom: 80),
                  child: OutlinedButton.icon(
                    onPressed: () =>
                        _showAddDialog(context, _selectedDayIndex),
                    icon: const Icon(Icons.add),
                    label: const Text('Add Activity'),
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                  ),
                );
              }
              final item = selectedDay.items[index];
              return _ItineraryItemCard(
                item: item,
                index: index,
                onDelete: () => context.read<TripProvider>()
                    .removeItineraryItem(
                  trip: trip,
                  dayIndex: _selectedDayIndex,
                  itemId: item.id,
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  void _showAddDialog(BuildContext context, int dayIndex) {
    final titleController = TextEditingController();
    final descController = TextEditingController();
    final timeController = TextEditingController();
    String selectedType = 'place';

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setModalState) => Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(ctx).viewInsets.bottom + 20,
            top: 20,
            left: 20,
            right: 20,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Text('Add Activity',
                      style: GoogleFonts.poppins(
                          fontSize: 18, fontWeight: FontWeight.w600)),
                  const Spacer(),
                  IconButton(
                    onPressed: () => Navigator.pop(ctx),
                    icon: const Icon(Icons.close),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              // Type selector
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    _typeChip('place', '📍 Place', selectedType,
                            (v) => setModalState(() => selectedType = v)),
                    _typeChip('activity', '🎯 Activity', selectedType,
                            (v) => setModalState(() => selectedType = v)),
                    _typeChip('food', '🍽️ Food', selectedType,
                            (v) => setModalState(() => selectedType = v)),
                    _typeChip('transport', '🚌 Transport', selectedType,
                            (v) => setModalState(() => selectedType = v)),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              AppTextField(
                label: 'Title *',
                hint: 'e.g., Visit Eiffel Tower',
                controller: titleController,
              ),
              const SizedBox(height: 12),
              AppTextField(
                label: 'Time (Optional)',
                hint: 'e.g., 10:00 AM',
                controller: timeController,
                prefixIcon: Icons.schedule_outlined,
              ),
              const SizedBox(height: 12),
              AppTextField(
                label: 'Notes (Optional)',
                hint: 'Any extra info...',
                controller: descController,
                maxLines: 2,
              ),
              const SizedBox(height: 20),
              GradientButton(
                label: 'Add to Itinerary',
                onPressed: () async {
                  if (titleController.text.trim().isEmpty) return;
                  Navigator.pop(ctx);
                  await context.read<TripProvider>().addItineraryItem(
                    trip: widget.trip,
                    dayIndex: dayIndex,
                    title: titleController.text.trim(),
                    type: selectedType,
                    description: descController.text.trim().isEmpty
                        ? null
                        : descController.text.trim(),
                    time: timeController.text.trim().isEmpty
                        ? null
                        : timeController.text.trim(),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _typeChip(String value, String label, String selected,
      Function(String) onSelect) {
    final isSelected = value == selected;
    return GestureDetector(
      onTap: () => onSelect(value),
      child: Container(
        margin: const EdgeInsets.only(right: 8),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected ? AppColors.primary : Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isSelected ? AppColors.primary : AppColors.border,
          ),
        ),
        child: Text(label,
            style: GoogleFonts.poppins(
                fontSize: 13,
                fontWeight: FontWeight.w500,
                color: isSelected ? Colors.white : AppColors.textPrimary)),
      ),
    );
  }
}

class _ItineraryItemCard extends StatelessWidget {
  final ItineraryItem item;
  final int index;
  final VoidCallback onDelete;

  const _ItineraryItemCard({
    required this.item,
    required this.index,
    required this.onDelete,
  });

  IconData get _typeIcon {
    switch (item.type) {
      case 'place':
        return Icons.location_on_outlined;
      case 'food':
        return Icons.restaurant_outlined;
      case 'transport':
        return Icons.directions_bus_outlined;
      default:
        return Icons.star_outline;
    }
  }

  Color get _typeColor {
    switch (item.type) {
      case 'place':
        return AppColors.primary;
      case 'food':
        return AppColors.accent;
      case 'transport':
        return AppColors.warning;
      default:
        return AppColors.success;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Timeline
        Column(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: _typeColor.withOpacity(0.12),
                shape: BoxShape.circle,
              ),
              child: Icon(_typeIcon, size: 18, color: _typeColor),
            ),
            Container(
              width: 2,
              height: 40,
              color: AppColors.border,
            ),
          ],
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Container(
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.border),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(item.title,
                          style: GoogleFonts.poppins(
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                              color: AppColors.textPrimary)),
                      if (item.time != null) ...[
                        const SizedBox(height: 2),
                        Row(
                          children: [
                            Icon(Icons.schedule,
                                size: 12, color: AppColors.textSecondary),
                            const SizedBox(width: 4),
                            Text(item.time!,
                                style: GoogleFonts.poppins(
                                    fontSize: 12,
                                    color: AppColors.textSecondary)),
                          ],
                        ),
                      ],
                      if (item.description != null &&
                          item.description!.isNotEmpty) ...[
                        const SizedBox(height: 4),
                        Text(item.description!,
                            style: GoogleFonts.poppins(
                                fontSize: 12,
                                color: AppColors.textSecondary)),
                      ],
                    ],
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.delete_outline,
                      size: 18, color: AppColors.error),
                  onPressed: onDelete,
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}