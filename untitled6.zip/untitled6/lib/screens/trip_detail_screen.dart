import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';      // ← fixes all GoogleFonts errors
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';                      // ← fixes DateFormat error
import '../app_color.dart';                           // ← fixes all AppColors errors
import '../provider/auth_provider.dart';              // ← fixes AuthProvider error
import '../provider/weather_provider.dart';           // ← fixes WeatherProvider error
import '../model/trip_model.dart';
import '../provider/trip_provider.dart';
import 'Itinerary_screen.dart';
import 'weather_tab.dart';                            // ← fixes WeatherTab error
import 'chat_screen.dart';   // ← add this line
class TripDetailScreen extends StatefulWidget {
  final TripModel trip;
  const TripDetailScreen({super.key, required this.trip});

  @override
  State<TripDetailScreen> createState() => _TripDetailScreenState();
}

class _TripDetailScreenState extends State<TripDetailScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final _dateFormat = DateFormat('MMM d, yyyy');

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    // Pre-fetch weather
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context
          .read<WeatherProvider>()
          .fetchWeather(widget.trip.destination.split(',').first.trim());
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _confirmDelete(TripModel trip) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text('Delete Trip',
            style: GoogleFonts.poppins(fontWeight: FontWeight.w600)),
        content: Text(
            'Are you sure you want to delete "${trip.title}"? This cannot be undone.',
            style: GoogleFonts.poppins(fontSize: 14)),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancel')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text('Delete',
                style: GoogleFonts.poppins(color: AppColors.error)),
          ),
        ],
      ),
    );
    if (confirm == true && mounted) {
      await context.read<TripProvider>().deleteTrip(trip.id);
      if (mounted) Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthProvider>().currentUser;

    return StreamBuilder<TripModel?>(
      stream: context.read<TripProvider>().getTripStream(widget.trip.id),
      builder: (context, snapshot) {
        final trip = snapshot.data ?? widget.trip;

        return Scaffold(
          backgroundColor: AppColors.background,
          body: NestedScrollView(
            headerSliverBuilder: (context, innerBoxIsScrolled) => [
              SliverAppBar(
                expandedHeight: 200,
                pinned: true,
                backgroundColor: AppColors.primary,
                leading: IconButton(
                  icon: const Icon(Icons.arrow_back_ios_new_rounded,
                      color: Colors.white),
                  onPressed: () => Navigator.pop(context),
                ),
                actions: [
                  if (user?.uid == trip.creatorId)
                    IconButton(
                      icon: const Icon(Icons.delete_outline,
                          color: Colors.white),
                      onPressed: () => _confirmDelete(trip),
                    ),
                  IconButton(
                    icon: const Icon(Icons.chat_bubble_outline,
                        color: Colors.white),
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => ChatScreen(trip: trip)),
                    ),
                  ),
                ],
                flexibleSpace: FlexibleSpaceBar(
                  background: Container(
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        colors: [AppColors.gradientStart, AppColors.gradientEnd],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                    ),
                    child: Stack(
                      children: [
                        Positioned(
                          right: -30,
                          bottom: -30,
                          child: Icon(Icons.flight,
                              size: 180,
                              color: Colors.white.withOpacity(0.08)),
                        ),
                        Padding(
                          padding: const EdgeInsets.fromLTRB(20, 80, 20, 20),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Text(trip.title,
                                  style: GoogleFonts.poppins(
                                      fontSize: 22,
                                      fontWeight: FontWeight.w700,
                                      color: Colors.white)),
                              const SizedBox(height: 6),
                              Row(
                                children: [
                                  const Icon(Icons.location_on,
                                      size: 14, color: Colors.white70),
                                  const SizedBox(width: 4),
                                  Text(trip.destination,
                                      style: GoogleFonts.poppins(
                                          fontSize: 13,
                                          color: Colors.white70)),
                                  const SizedBox(width: 16),
                                  const Icon(Icons.calendar_today,
                                      size: 14, color: Colors.white70),
                                  const SizedBox(width: 4),
                                  Text(
                                    '${_dateFormat.format(trip.startDate)} – ${_dateFormat.format(trip.endDate)}',
                                    style: GoogleFonts.poppins(
                                        fontSize: 13,
                                        color: Colors.white70),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                bottom: TabBar(
                  controller: _tabController,
                  indicatorColor: Colors.white,
                  indicatorWeight: 3,
                  labelColor: Colors.white,
                  unselectedLabelColor: Colors.white60,
                  labelStyle: GoogleFonts.poppins(
                      fontSize: 13, fontWeight: FontWeight.w600),
                  tabs: const [
                    Tab(text: 'Itinerary'),
                    Tab(text: 'Weather'),
                    Tab(text: 'Details'),
                  ],
                ),
              ),
            ],
            body: TabBarView(
              controller: _tabController,
              children: [
                ItineraryScreen(trip: trip),
                WeatherTab(city: trip.destination),
                _DetailsTab(trip: trip),
              ],
            ),
          ),
          floatingActionButton: FloatingActionButton.extended(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => ChatScreen(trip: trip)),
            ),
            backgroundColor: AppColors.primary,
            icon: const Icon(Icons.chat_bubble_outline, color: Colors.white),
            label: Text('Group Chat',
                style: GoogleFonts.poppins(
                    color: Colors.white, fontWeight: FontWeight.w600)),
          ),
        );
      },
    );
  }
}

class _DetailsTab extends StatelessWidget {
  final TripModel trip;
  const _DetailsTab({required this.trip});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Stats row
          Row(
            children: [
              Expanded(
                child: _StatCard(
                  icon: Icons.schedule_outlined,
                  label: 'Duration',
                  value: '${trip.durationDays} days',
                  color: AppColors.primary,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _StatCard(
                  icon: Icons.people_outline,
                  label: 'Members',
                  value: '${trip.memberIds.length}',
                  color: AppColors.accent,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _StatCard(
                  icon: Icons.checklist_outlined,
                  label: 'Activities',
                  value: '${trip.itinerary.fold(0, (sum, d) => sum + d.items.length)}',
                  color: AppColors.success,
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),

          if (trip.notes.isNotEmpty) ...[
            Text('Notes',
                style: GoogleFonts.poppins(
                    fontSize: 15, fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.border),
              ),
              child: Text(trip.notes,
                  style: GoogleFonts.poppins(
                      fontSize: 14, color: AppColors.textSecondary,
                      height: 1.6)),
            ),
            const SizedBox(height: 20),
          ],

          // Add members section
          Text('Members',
              style: GoogleFonts.poppins(
                  fontSize: 15, fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.border),
            ),
            child: Column(
              children: [
                Row(
                  children: [
                    const Icon(Icons.people_outline,
                        size: 18, color: AppColors.textSecondary),
                    const SizedBox(width: 8),
                    Text('${trip.memberIds.length} member(s) in this trip',
                        style: GoogleFonts.poppins(
                            fontSize: 13, color: AppColors.textSecondary)),
                  ],
                ),
                const SizedBox(height: 12),
                _AddMemberField(trip: trip),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color color;
  const _StatCard(
      {required this.icon,
        required this.label,
        required this.value,
        required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        children: [
          Icon(icon, size: 22, color: color),
          const SizedBox(height: 6),
          Text(value,
              style: GoogleFonts.poppins(
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textPrimary)),
          Text(label,
              style: GoogleFonts.poppins(
                  fontSize: 11, color: AppColors.textSecondary)),
        ],
      ),
    );
  }
}

class _AddMemberField extends StatefulWidget {
  final TripModel trip;
  const _AddMemberField({required this.trip});

  @override
  State<_AddMemberField> createState() => _AddMemberFieldState();
}

class _AddMemberFieldState extends State<_AddMemberField> {
  final _controller = TextEditingController();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: TextField(
            controller: _controller,
            style: GoogleFonts.poppins(fontSize: 14),
            decoration: InputDecoration(
              hintText: 'Enter member user ID',
              hintStyle: GoogleFonts.poppins(
                  fontSize: 13, color: AppColors.textSecondary),
              contentPadding: const EdgeInsets.symmetric(
                  horizontal: 12, vertical: 10),
              isDense: true,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: const BorderSide(color: AppColors.border),
              ),
            ),
          ),
        ),
        const SizedBox(width: 8),
        ElevatedButton(
          onPressed: () async {
            final uid = _controller.text.trim();
            if (uid.isEmpty) return;
            await context
                .read<TripProvider>()
                .addMember(widget.trip.id, uid);
            _controller.clear();
          },
          style: ElevatedButton.styleFrom(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          ),
          child: const Text('Add'),
        ),
      ],
    );
  }
}