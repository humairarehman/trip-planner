class TripModel {
  final String id;
  final String title;
  final String destination;
  final DateTime startDate;
  final DateTime endDate;
  final String notes;
  final String creatorId;
  final List<String> memberIds;
  final List<ItineraryDay> itinerary;
  final DateTime createdAt;
  final String? coverImageUrl;

  TripModel({
    required this.id,
    required this.title,
    required this.destination,
    required this.startDate,
    required this.endDate,
    this.notes = '',
    required this.creatorId,
    required this.memberIds,
    this.itinerary = const [],
    required this.createdAt,
    this.coverImageUrl,
  });

  int get durationDays => endDate.difference(startDate).inDays + 1;

  bool get isPast => endDate.isBefore(DateTime.now());
  bool get isUpcoming => startDate.isAfter(DateTime.now());
  bool get isOngoing =>
      startDate.isBefore(DateTime.now()) && endDate.isAfter(DateTime.now());

  factory TripModel.fromMap(Map<String, dynamic> map, String id) {
    return TripModel(
      id: id,
      title: map['title'] ?? '',
      destination: map['destination'] ?? '',
      startDate: DateTime.fromMillisecondsSinceEpoch(map['startDate'] ?? 0),
      endDate: DateTime.fromMillisecondsSinceEpoch(map['endDate'] ?? 0),
      notes: map['notes'] ?? '',
      creatorId: map['creatorId'] ?? '',
      memberIds: List<String>.from(map['memberIds'] ?? []),
      itinerary: (map['itinerary'] as List<dynamic>? ?? [])
          .map((e) => ItineraryDay.fromMap(e))
          .toList(),
      createdAt: map['createdAt'] != null
          ? DateTime.fromMillisecondsSinceEpoch(map['createdAt'])
          : DateTime.now(),
      coverImageUrl: map['coverImageUrl'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'title': title,
      'destination': destination,
      'startDate': startDate.millisecondsSinceEpoch,
      'endDate': endDate.millisecondsSinceEpoch,
      'notes': notes,
      'creatorId': creatorId,
      'memberIds': memberIds,
      'itinerary': itinerary.map((e) => e.toMap()).toList(),
      'createdAt': createdAt.millisecondsSinceEpoch,
      'coverImageUrl': coverImageUrl,
    };
  }

  TripModel copyWith({
    String? title,
    String? destination,
    DateTime? startDate,
    DateTime? endDate,
    String? notes,
    List<String>? memberIds,
    List<ItineraryDay>? itinerary,
    String? coverImageUrl,
  }) {
    return TripModel(
      id: id,
      title: title ?? this.title,
      destination: destination ?? this.destination,
      startDate: startDate ?? this.startDate,
      endDate: endDate ?? this.endDate,
      notes: notes ?? this.notes,
      creatorId: creatorId,
      memberIds: memberIds ?? this.memberIds,
      itinerary: itinerary ?? this.itinerary,
      createdAt: createdAt,
      coverImageUrl: coverImageUrl ?? this.coverImageUrl,
    );
  }
}

class ItineraryDay {
  final int dayNumber;
  final DateTime date;
  final List<ItineraryItem> items;

  ItineraryDay({
    required this.dayNumber,
    required this.date,
    this.items = const [],
  });

  factory ItineraryDay.fromMap(Map<String, dynamic> map) {
    return ItineraryDay(
      dayNumber: map['dayNumber'] ?? 0,
      date: DateTime.fromMillisecondsSinceEpoch(map['date'] ?? 0),
      items: (map['items'] as List<dynamic>? ?? [])
          .map((e) => ItineraryItem.fromMap(e))
          .toList(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'dayNumber': dayNumber,
      'date': date.millisecondsSinceEpoch,
      'items': items.map((e) => e.toMap()).toList(),
    };
  }
}

class ItineraryItem {
  final String id;
  final String title;
  final String? description;
  final String type; // 'place', 'activity', 'food', 'transport'
  final String? time;

  ItineraryItem({
    required this.id,
    required this.title,
    this.description,
    this.type = 'activity',
    this.time,
  });

  factory ItineraryItem.fromMap(Map<String, dynamic> map) {
    return ItineraryItem(
      id: map['id'] ?? '',
      title: map['title'] ?? '',
      description: map['description'],
      type: map['type'] ?? 'activity',
      time: map['time'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'type': type,
      'time': time,
    };
  }
}