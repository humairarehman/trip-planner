class WeatherModel {
  final String city;
  final double temperature;
  final double feelsLike;
  final double tempMin;
  final double tempMax;
  final String description;
  final String icon;
  final int humidity;
  final double windSpeed;
  final DateTime date;

  WeatherModel({
    required this.city,
    required this.temperature,
    required this.feelsLike,
    required this.tempMin,
    required this.tempMax,
    required this.description,
    required this.icon,
    required this.humidity,
    required this.windSpeed,
    required this.date,
  });

  String get iconUrl => 'https://openweathermap.org/img/wn/$icon@2x.png';

  factory WeatherModel.fromMap(Map<String, dynamic> map) {
    final main = map['main'] ?? {};
    final weather = (map['weather'] as List?)?.first ?? {};
    final wind = map['wind'] ?? {};

    return WeatherModel(
      city: map['name'] ?? '',
      temperature: (main['temp'] ?? 0.0).toDouble(),
      feelsLike: (main['feels_like'] ?? 0.0).toDouble(),
      tempMin: (main['temp_min'] ?? 0.0).toDouble(),
      tempMax: (main['temp_max'] ?? 0.0).toDouble(),
      description: weather['description'] ?? '',
      icon: weather['icon'] ?? '01d',
      humidity: main['humidity'] ?? 0,
      windSpeed: (wind['speed'] ?? 0.0).toDouble(),
      date: DateTime.now(),
    );
  }
}

class ForecastDay {
  final DateTime date;
  final double tempMin;
  final double tempMax;
  final String description;
  final String icon;

  ForecastDay({
    required this.date,
    required this.tempMin,
    required this.tempMax,
    required this.description,
    required this.icon,
  });

  String get iconUrl => 'https://openweathermap.org/img/wn/$icon@2x.png';

  factory ForecastDay.fromMap(Map<String, dynamic> map) {
    final main = map['main'] ?? {};
    final weather = (map['weather'] as List?)?.first ?? {};
    return ForecastDay(
      date: DateTime.fromMillisecondsSinceEpoch((map['dt'] ?? 0) * 1000),
      tempMin: (main['temp_min'] ?? 0.0).toDouble(),
      tempMax: (main['temp_max'] ?? 0.0).toDouble(),
      description: weather['description'] ?? '',
      icon: weather['icon'] ?? '01d',
    );
  }
}